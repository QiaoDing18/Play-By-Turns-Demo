window.onload = function(){
	setTimeout(changeImg, 3000);
	
	var rightBtn = document.getElementById("right-btn");
	var leftBtn = document.getElementById("left-btn");

	rightBtn.onclick = function(){
		clearTimeout(changeImg);
		//定义个计数器
		var count = 0;
		//我也不知道为啥就是想写个闭包
		var tempHandle = handleChanger();
		setTimeout(doMove, 10);
		//执行图片平移
		function doMove(){
			count++;
			tempHandle();
			//满足条件就跳出
			if(count === 140){
				clearTimeout(doMove);
				return;
			}
			setTimeout(doMove, 10);
		}
	};
	leftBtn.onclick = function(){
		//定义个计数器
		var count = 0;
		//我也不知道为啥就是想写个闭包
		var tempHandle = handleChangerForLeft();
		setTimeout(doMove, 10);
		//执行图片平移
		function doMove(){
			count++;
			tempHandle();
			//满足条件就跳出
			if(count === 140){
				clearTimeout(doMove);
				return;
			}
			setTimeout(doMove, 10);
		}
	};
};

function changeImg(){
	//定义个计数器
	var count = 0;
	//我也不知道为啥就是想写个闭包
	var tempHandle = handleChanger();
	setTimeout(doMove, 10);
	//执行图片平移
	function doMove(){
		count++;
		tempHandle();
		//满足条件就跳出
		if(count === 140){
			clearTimeout(doMove);
			return;
		}
		setTimeout(doMove, 10);
	}
	setTimeout(changeImg, 3000);
}

function handleChanger(){
	//写了个闭包
	function moveImg(){
		var oBox = document.getElementsByClassName("img-box")[0];

		// 处理距左距离
		oBox.style.left = oBox.style.left.slice(0, -2)  - 5 + "px";
		// 如果到结尾就回到开头
		if(oBox.style.left === "-3500px"){
			oBox.style.left = 0 + "px";
		}
	}
	return moveImg;
}

function handleChangerForLeft(){
	//写了个闭包
	function moveImg(){
		var oBox = document.getElementsByClassName("img-box")[0];

		// 处理距左距离
		oBox.style.left = -(-(oBox.style.left.slice(0, -2))) + 5 + "px";
		// 如果到结尾就回到开头
		if(oBox.style.left === "-3500px"){
			oBox.style.left = 0 + "px";
		}
		if(oBox.style.left.slice(0, -2) > 700){
			oBox.style.left = "-2800px";
		}
	}
	return moveImg;
}