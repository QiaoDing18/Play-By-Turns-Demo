window.onload = function(){
	playByTurns();
};

//轮播图实现的函数
function playByTurns(){
	//获取图片
	//var oImg = document.getElementsByClassName('imgs');
	//获取到盒子
	var oBox = document.getElementsByClassName('imgBox')[0];
	//获取到左右按钮
	var leftBtn = document.getElementById('left-btn');
	var rightBtn = document.getElementById('right-btn');
	//滑动事件
	leftBtn.onclick = function(){
		var tempData1 = 0;
		tempData1 = oBox.offsetLeft + 1400 + "px";
		if(oBox.offsetLeft >= -700){
			oBox.style.left = -2800 + "px";
		}else{
			// console.log(tempData1);
			oBox.style.left = tempData1;
		}
		// console.log(oBox.style.left);
	};
	rightBtn.onclick = function(){
		var tempData2 = 0;
		tempData2 = oBox.offsetLeft + "px";
		if(oBox.offsetLeft <= -4200){
			oBox.style.left = -700 + "px";
		}else{
			oBox.style.left = tempData2;
		}
		// console.log(oBox.style.left);
	};
	setInterval(setStyle, 3000);
}

function setStyle(){
	//获取到盒子
	var oBox = document.getElementsByClassName('imgBox')[0];
	var count = 0;
	var timer = setTimeout(playStyle, 30);
	function playStyle(){
		//无限循环条件
		if(oBox.offsetLeft <= -4200){
			oBox.offsetLeft = -700;
			oBox.style.left = 0 + "px";
		}
		//有边框15px, 初始的最后一张图片700px
		oBox.style.left = oBox.offsetLeft - 10 + 700 + "px";
		// console.log(oBox.offsetLeft);
		count++;
		if(count == 70){
			clearInterval(timer);
		}else{
	        setTimeout(playStyle, 30);
		}
	}
}